# gnome-shell-suseprime-switcher
Gnome Shell extension for switching between GPUs

Installation:
```sh
meson --prefix=/usr build
cd build
ninja install
```
